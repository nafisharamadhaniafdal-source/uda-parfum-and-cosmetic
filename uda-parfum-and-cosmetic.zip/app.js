// Uda Parfum & Cosmetic - Frontend Store
const state = {
  products: [
    { id: 'p1', title: 'Aura Luxe EDP 50ml', price: 379000, was: 459000, img: 'https://images.unsplash.com/photo-1585386959984-a41552231677?q=80&w=1200&auto=format&fit=crop', tag: 'Best Seller' },
    { id: 'p2', title: 'Velvet Kiss Lip Cream', price: 99000, was: 139000, img: 'https://images.unsplash.com/photo-1612815154858-60aa4c59eaa0?q=80&w=1200&auto=format&fit=crop', tag: 'Baru' },
    { id: 'p3', title: 'HydraGlow Serum 30ml', price: 149000, was: 189000, img: 'https://images.unsplash.com/photo-1512496015851-a90fb38ba796?q=80&w=1200&auto=format&fit=crop', tag: 'Promo' },
    { id: 'p4', title: 'Silk Mist Body Spray', price: 79000, was: 99000, img: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=1200&auto=format&fit=crop', tag: 'Favorit' },
    { id: 'p5', title: 'Prime Matte Cushion', price: 179000, was: 219000, img: 'https://images.unsplash.com/photo-1582092723813-2a6c3790df52?q=80&w=1200&auto=format&fit=crop', tag: 'Best Seller' },
    { id: 'p6', title: 'Rose Petal Toner', price: 89000, was: 109000, img: 'https://images.unsplash.com/photo-1629198735661-a3c64fd29379?q=80&w=1200&auto=format&fit=crop', tag: 'Segar' },
    { id: 'p7', title: 'Midnight Oud EDP 100ml', price: 499000, was: 599000, img: 'https://images.unsplash.com/photo-1563170351-be82bc888aa4?q=80&w=1200&auto=format&fit=crop', tag: 'Mewah' },
    { id: 'p8', title: 'Daily Sunscreen SPF 50+', price: 79000, was: 99000, img: 'https://images.unsplash.com/photo-1629198749762-1fb3dfcc1a64?q=80&w=1200&auto=format&fit=crop', tag: 'Wajib' }
  ],
  cart: JSON.parse(localStorage.getItem('uda_cart') || '[]'),
  slideIndex: 0
};

// Utilities
const fmt = n => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(n);
const el = sel => document.querySelector(sel);
const els = sel => document.querySelectorAll(sel);

function saveCart() {
  localStorage.setItem('uda_cart', JSON.stringify(state.cart));
  renderCart();
}

function addToCart(productId) {
  const item = state.cart.find(i => i.id === productId);
  if (item) item.qty += 1;
  else state.cart.push({ id: productId, qty: 1 });
  saveCart();
}

function setQty(productId, qty) {
  const item = state.cart.find(i => i.id === productId);
  if (!item) return;
  item.qty = Math.max(1, qty);
  saveCart();
}

function removeItem(productId) {
  state.cart = state.cart.filter(i => i.id !== productId);
  saveCart();
}

function cartTotal() {
  return state.cart.reduce((sum, it) => {
    const p = state.products.find(p => p.id === it.id);
    return sum + (p ? p.price * it.qty : 0);
  }, 0);
}

function renderProducts() {
  const grid = el('#productGrid');
  grid.innerHTML = state.products.map(p => `
    <article class="card" data-animate="fade-up">
      <div class="media">
        <img src="${p.img}" alt="${p.title}" loading="lazy">
        <span class="badge">${p.tag}</span>
      </div>
      <div class="content">
        <h3>${p.title}</h3>
        <div class="price">
          <span class="now">${fmt(p.price)}</span>
          <span class="was">${fmt(p.was)}</span>
        </div>
        <div class="actions">
          <button class="btn ghost" onclick="addToCart('${p.id}')">Tambah ke Keranjang</button>
          <button class="btn primary" onclick="buyNow('${p.id}')">Beli Sekarang</button>
        </div>
      </div>
    </article>
  `).join('');
}

function renderCart() {
  // Update count
  const count = state.cart.reduce((n, it) => n + it.qty, 0);
  el('#cartCount').textContent = count;

  // Items
  const wrap = el('#cartItems');
  if (!state.cart.length) {
    wrap.innerHTML = `<p>Keranjang masih kosong. Yuk belanja dulu ✨</p>`;
  } else {
    wrap.innerHTML = state.cart.map(it => {
      const p = state.products.find(p => p.id === it.id);
      if (!p) return '';
      return `
        <div class="cart-item">
          <img src="${p.img}" alt="${p.title}">
          <div>
            <div class="title">${p.title}</div>
            <div class="muted">${fmt(p.price)} • ${fmt(p.price * it.qty)}</div>
            <div class="qty">
              <button onclick="decrement('${p.id}')">−</button>
              <span>${it.qty}</span>
              <button onclick="increment('${p.id}')">+</button>
            </div>
          </div>
          <button class="icon-btn" onclick="removeItem('${p.id}')">✕</button>
        </div>
      `;
    }).join('');
  }

  // Total
  el('#cartTotal').textContent = fmt(cartTotal());
}

function increment(id){ const it = state.cart.find(i => i.id === id); if (it){ it.qty++; saveCart(); } }
function decrement(id){ const it = state.cart.find(i => i.id === id); if (it){ it.qty = Math.max(1, it.qty - 1); saveCart(); } }

// Drawer
const drawer = el('#cartDrawer');
const overlay = el('#overlay');
function openCart(){
  drawer.classList.add('open');
  overlay.classList.add('show');
  drawer.setAttribute('aria-hidden', 'false');
}
function closeCart(){
  drawer.classList.remove('open');
  overlay.classList.remove('show');
  drawer.setAttribute('aria-hidden', 'true');
}

// Slider
function initSlider(){
  const slides = el('#slides');
  const images = slides.querySelectorAll('img');
  const dots = el('#sliderDots');

  function gotoSlide(i){
    state.slideIndex = (i + images.length) % images.length;
    slides.style.transform = `translateX(-${state.slideIndex * 100}%)`;
    dots.querySelectorAll('button').forEach((b,bi)=> b.classList.toggle('active', bi===state.slideIndex));
  }

  dots.innerHTML = Array.from(images).map((_,i)=>`<button aria-label="Ke slide ${i+1}" ${i===0?'class="active"':''}></button>`).join('');
  dots.querySelectorAll('button').forEach((b,i)=> b.addEventListener('click',()=>gotoSlide(i)));
  el('#prevSlide').addEventListener('click',()=>gotoSlide(state.slideIndex-1));
  el('#nextSlide').addEventListener('click',()=>gotoSlide(state.slideIndex+1));

  setInterval(()=>gotoSlide(state.slideIndex+1), 5000);
}

// Checkout
function buyNow(id){
  addToCart(id);
  openCart();
}

function setupCheckout(){
  el('#checkoutBtn').addEventListener('click', () => {
    if (!state.cart.length) {
      alert('Keranjang masih kosong.');
      return;
    }
    el('#checkoutModal').showModal();
  });

  el('#payNow').addEventListener('click', (e) => {
    e.preventDefault();
    const name = el('#coName').value.trim();
    const phone = el('#coPhone').value.trim();
    const address = el('#coAddress').value.trim();
    const payment = el('#coPayment').value;

    if (!name || !phone || !address || !payment) return;

    const order = {
      name, phone, address, payment,
      items: state.cart.map(it => {
        const p = state.products.find(x => x.id === it.id);
        return { id: it.id, title: p?.title, qty: it.qty, price: p?.price, subtotal: (p?.price || 0) * it.qty };
      }),
      total: cartTotal(),
      createdAt: new Date().toISOString()
    };

    // Save a "receipt" JSON to download
    const blob = new Blob([JSON.stringify(order, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `order-uda-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);

    alert('Terima kasih! Pesanan kamu tersimpan sebagai file JSON. Kami akan menghubungi via WhatsApp untuk konfirmasi.');
    state.cart = [];
    saveCart();
    el('#checkoutModal').close();
    closeCart();
  });
}

// Newsletter
function setupNewsletter(){
  el('#subscribeBtn').addEventListener('click', () => {
    const email = el('#email').value.trim();
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){
      el('#subscribeMsg').textContent = 'Email tidak valid.';
      return;
    }
    el('#subscribeMsg').textContent = 'Terima kasih! Kamu sudah terdaftar.';
    setTimeout(()=> el('#subscribeMsg').textContent = '', 4000);
    el('#email').value='';
  });
}

// Music toggle
function setupMusic(){
  const audio = el('#bg-audio');
  const btn = el('#musicToggle');
  btn.addEventListener('click', async () => {
    try{
      if(audio.muted){
        audio.muted = false;
        await audio.play();
        btn.textContent = '❚❚ Pause Music';
      } else if (!audio.paused){
        audio.pause();
        btn.textContent = '► Play Music';
      } else {
        await audio.play();
        btn.textContent = '❚❚ Pause Music';
      }
    }catch(err){
      console.log(err);
      alert('Browser memblokir autoplay. Tekan tombol lagi untuk memulai musik.');
    }
  });
}

// Animations on scroll
function setupAnimations(){
  const obs = new IntersectionObserver((entries)=>{
    entries.forEach(e=>{
      if(e.isIntersecting) e.target.classList.add('in');
    });
  }, { threshold: .15 });
  document.querySelectorAll('[data-animate]').forEach(el=> obs.observe(el));
}

function setupEvents(){
  el('#cartButton').addEventListener('click', openCart);
  el('#closeCart').addEventListener('click', closeCart);
  el('#clearCart').addEventListener('click', () => { state.cart = []; saveCart(); });
  overlay.addEventListener('click', closeCart);
}

// Init
window.addEventListener('DOMContentLoaded', () => {
  renderProducts();
  renderCart();
  setupEvents();
  setupCheckout();
  setupNewsletter();
  setupMusic();
  setupAnimations();
  initSlider();
  document.getElementById('year').textContent = new Date().getFullYear();
});
